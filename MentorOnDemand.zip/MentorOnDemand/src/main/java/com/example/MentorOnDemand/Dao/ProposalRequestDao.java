package com.example.MentorOnDemand.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.MentorOnDemand.Model.ProposalRequest;

public interface ProposalRequestDao extends JpaRepository<ProposalRequest, Integer>{

}
