package com.example.MentorOnDemand.Model;

public class Admin {

}
